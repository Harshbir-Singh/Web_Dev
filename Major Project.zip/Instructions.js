//all done by me, grp members were not responding in chat.



// On Google, type "localhost:5000", and run "nodemon app.js" in the terminal.


//Login credentials for Admin: 
//<!-- Username : Admin -->
//<!--Password is 1279-->


//Register acc for the user and then sign in: 
