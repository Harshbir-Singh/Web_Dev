const express = require("express")
const mongoose = require("mongoose")
const path = require("path")
const bodyParser = require('body-parser')
const app = express()
const port = 5000
app.use(bodyParser.urlencoded({extended:true}))
app.use(bodyParser.json())
app.use(express.static(path.join(__dirname,"Main")))
app.get('/',(req,res)=>(

    res.sendFile(__dirname + "/Main/Main.html")
))

mongoose.connect("mongodb://localhost:27017/",{

}).then(()=>(
    console.log("MongoDb connnected")
))

app.use(bodyParser.json());

let users = []; 

app.post('/register', (req, res) => {
    const { name, mobile, password } = req.body;
    
  
    if (users.find(user => user.mobile === mobile)) {
        return res.status(400).send('User already exists');
    }
    
    users.push({ name, mobile, password });
    res.status(201).send('User registered successfully');
});

app.post('/login', (req, res) => {
    const { mobile, password } = req.body;
    
    const user = users.find(user => user.mobile === mobile && user.password === password);
    
    if (user) {
        res.status(200).send('Login successful');
    } else {
        res.status(401).send('Invalid credentials');
    }
});

app.listen(port,()=>(console.log('Server is running on No:',port)))


