document.addEventListener("DOMContentLoaded", function () {
    const items = document.getElementById("Items");
    const searchInput = document.querySelector(".search input");

    function loadProducts() {
        const products = JSON.parse(localStorage.getItem("products")) || [];

        products.slice(0, 10).forEach((product) => {
            const listItem = document.createElement("li");
            listItem.innerHTML = `
                <nav>
                    <img class="image" src="${product.imageUrl}">
                </nav>
                <p class="name">${product.name}</p>
                <p class="price"><b>${product.price}</b></p>
                <nav>
                    <button class="delete"><b><i class="bi bi-trash3"></i> Delete</b></button>
                </nav>
            `;
            items.appendChild(listItem);
        });
    }

    function deleteItem(event) {
        if (event.target.closest(".delete")) {
            const listItem = event.target.closest("li");
            if (listItem) {
                const productName = listItem.querySelector(".name").textContent;
                const productImageUrl = listItem.querySelector(".image").src;

                listItem.remove();

                let products = JSON.parse(localStorage.getItem("products")) || [];
                products = products.filter(product => 
                    !(product.name === productName && product.imageUrl === productImageUrl)
                );
                localStorage.setItem("products", JSON.stringify(products));
            }
        }
    }

    function filterProducts() {
        const filterText = searchInput.value.toLowerCase();
        const listItems = items.getElementsByTagName("li");

        Array.from(listItems).forEach((listItem) => {
            const productName = listItem.querySelector(".name").textContent.toLowerCase();
            if (productName.includes(filterText)) {
                listItem.style.display = "";
            } else {
                listItem.style.display = "none";
            }
        });
    }

    searchInput.addEventListener("input", filterProducts);
    items.addEventListener("click", deleteItem);

    loadProducts();
});


