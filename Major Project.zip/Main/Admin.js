const form = document.querySelector("form")
form.addEventListener("submit",Indicator)

function Indicator(event){
    event.preventDefault()

    const username = form.username.value
    const password = form.password.value

    const authenticated = authentication(username,password)

    if(authenticated){
        window.location.href = "AdminDashboard.html"
        alert("Success!")
        
    }
    else{
        alert("Wrong!")
    }

};

function authentication(username,password){
    if(username === "Admin" && password === "1279"){
        return true

    }
    else{
        return false
    }
}

function Forgot(){
    alert("Password is 1279")
}