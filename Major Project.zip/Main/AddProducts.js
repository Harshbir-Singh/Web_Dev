document.addEventListener("DOMContentLoaded", function () {
    const addProductForm = document.getElementById("addProductForm");
    const items = document.getElementById("Items");

    addProductForm.addEventListener("submit", function (event) {
        event.preventDefault();

      
        let products = JSON.parse(localStorage.getItem("products")) || [];


        if (products.length >= 8) {
            alert("You cannot add more than 10 products.");
            return;
        }

        const fileInput = document.getElementById("file");
        const itemNameInput = document.getElementById("itemName");
        const priceInput = document.getElementById("price");

        const file = fileInput.files[0];
        const itemName = itemNameInput.value.trim();
        const price = priceInput.value.trim();

        if (!file || !itemName || !price) {
            alert("Please fill in all fields.");
            return;
        }

        const reader = new FileReader();
        reader.onload = function () {
            const imageUrl = reader.result;

            const newProduct = {
                imageUrl: imageUrl,
                name: itemName,
                price: `$${price}`
            };

            products.push(newProduct);

         
            localStorage.setItem("products", JSON.stringify(products));

           
            window.location.href = "Products.html";
        };

        reader.readAsDataURL(file);

    
    });

});
