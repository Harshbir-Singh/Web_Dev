// On Google, type "localhost:5000", and run "nodemon app.js" in the terminal.
//Login credentials: 
//<!-- Username : Harshbir Singh -->
//<!--Password in Forgot password-->
