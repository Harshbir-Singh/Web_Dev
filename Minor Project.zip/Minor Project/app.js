const express = require("express")
const mongoose = require("mongoose")
const path = require("path")
const bodyParser = require('body-parser')
const app = express()
const port = 5000
app.use(bodyParser.urlencoded({extended:true}))
app.use(bodyParser.json())
app.use(express.static(path.join(__dirname,"Main")))
app.get('/',(req,res)=>(

    res.sendFile(__dirname + "/Main/Login.html")
))

mongoose.connect("mongodb://localhost:27017/",{

}).then(()=>(
    console.log("MongoDb connnected")
))



const addSchema = new mongoose.Schema({
    BookID:{ type: String, unique: true },
    Name:String,
    Author:String,
    Price:Number,
    Quantity:Number,
})

const addSchema2 = new mongoose.Schema({
    BookID:String,
    StudentID:{type: String, unique: true },
    StudentName:String,
    Course:String,
    Branch:String,
})

const Data = mongoose.model('Data',addSchema);
const Student = mongoose.model('Student',addSchema2);


app.get('/countBooks', async (req, res) => {
    try {
        const bookCount = await Data.countDocuments();
        res.json({ count: bookCount });
    } catch (error) {
        res.status(500).send(error);
    }
});


app.get('/countStudents', async (req, res) => {
    try {
        const studentCount = await Student.countDocuments();
        res.json({ count: studentCount });
    } catch (error) {
        res.status(500).send(error);
    }
});


app.get('/countIssuedBooks', async (req, res) => {
    try {
        const issuedBookCount = await Student.countDocuments(); 
        res.json({ count: issuedBookCount });
    } catch (error) {
        res.status(500).send(error);
    }
});



app.post("/save", async (req, res) => {
    const { BookID, Name, Author, Price, Quantity } = req.body;
    
    try {
        const newData = new Data({ BookID, Name, Author, Price, Quantity });
        await newData.save();
        res.redirect('/Books.html');
    } catch (error) {
        if (error.code === 11000) { 
            res.status(400).send('Duplicate BookID');
        } else {
            res.status(500).send('Error saving book');
        }
    }
});

app.post("/submit", async (req, res) => {
    const { BookID, StudentID, StudentName, Course, Branch } = req.body;

    try {

        const book = await Data.findOne({ BookID });

        if (!book) {
            return res.status(404).send('Book not found');
        }

        if (book.Quantity <= 0) {
            return res.status(400).send('No copies of the book are available');
        }


        book.Quantity -= 1;
        await book.save();


        const newStudent = new Student({ BookID, StudentID, StudentName, Course, Branch });
        await newStudent.save();

        res.send('Book issued successfully');
    } catch (error) {
        if (error.code === 11000) { 
            res.status(400).send('Duplicate StudentID');
        } else {
            res.status(500).send('Failed to issue book');
            console.error(error);
        }
    }
});


app.listen(port,()=>(console.log('Server is running on No:',port)))


//Fetching data
app.get('/book', async (req, res) => {
    try {
        const data = await Data.find();
        res.json(data);
    } catch (error) {
        res.status(500).send(error);
    }
});

app.get('/student', async (req, res) => {
    try {
        const data = await Student.find();
        res.json(data);
    } catch (error) {
        res.status(500).send(error);
    }
});



// Updating book
app.put('/updateBook', async (req, res) => {
    const { bookID, bookName, author, price, quantity } = req.body;

    try {
        const existingBook = await Data.findOne({ BookID: bookID });

        if (!existingBook) {
            return res.status(404).send('Book not found');
        }

        const updatedBook = await Data.updateOne(
            { BookID: bookID },
            {
                $set: {
                    Name: bookName,
                    Author:author,
                    Price: price,
                    Quantity: quantity
                }
            }
        );

        res.send('Book updated successfully');
    } catch (error) {
        res.status(500).send('Failed to update book');
        console.error('Error updating book:', error);
    }
});



//delete book

app.put('/deleteBooks/:bookID/:quantity', async (req, res) => {
    const { bookID, quantity } = req.params;
    
    try {

        const book = await Data.findOne({ BookID: bookID });

        if (!book) {
            return res.status(404).send('Book not found');
        }

        if (book.Quantity === parseInt(quantity, 10)) {
            await Data.deleteOne({ BookID: bookID });
            return res.send('Book deleted successfully');
        } else if (book.Quantity > parseInt(quantity, 10)) {

            const updatedBook = await Data.updateOne(
                { BookID: bookID },
                { $set: { Quantity: book.Quantity - parseInt(quantity, 10) } }
            );
            return res.send('Book quantity updated successfully');
        } else {

            return res.status(400).send('Specified quantity exceeds available quantity');
        }
        
    } catch (error) {
        res.status(500).send('Failed to update or delete books');
        console.error(error);
    }
});

// Updating student records

app.post('/updateStudent', async (req, res) => {
    const { bookID, studentID, branch } = req.body;

    try {
       
        const newBook = await Data.findOne({ BookID: bookID });

        if (!newBook) {
            return res.status(404).send('Book ID not found');
        }

        if (newBook.Quantity <= 0) {
            return res.status(400).send('No quantity available for the new book');
        }

       
        const existingStudent = await Student.findOne({ StudentID: studentID });

        if (!existingStudent) {
            return res.status(404).send('Student ID not found');
        }

      
        const otherStudentWithSameID = await Student.findOne({ StudentID: studentID, _id: { $ne: existingStudent._id } });

        if (otherStudentWithSameID) {
            return res.status(400).send('Duplicate Student ID');
        }

     
        const updatedStudent = await Student.updateOne(
            { StudentID: studentID },
            { $set: { BookID: bookID, Branch: branch } }
        );

        if (updatedStudent.nModified === 0) {
            return res.status(404).send('Student record not found');
        }

     
        await Promise.all([
            Data.updateOne({ BookID: bookID }, { $inc: { Quantity: -1 } }),
            Data.updateOne({ BookID: existingStudent.BookID }, { $inc: { Quantity: 1 } })
        ]);

        res.send('Student record updated successfully');
    } catch (error) {
        res.status(500).send('Failed to update student record');
        console.error(error);
    }
});


//Deleting Records


app.delete('/deleteRecord', async (req, res) => {
    const { BookID, StudentID } = req.body;

    try {
        
        const result = await Student.deleteOne({ BookID, StudentID });

        if (result.deletedCount === 0) {
            return res.status(404).send('Record not found');
        }

        res.send('Record deleted successfully');
    } catch (error) {
        res.status(500).send('Failed to delete record');
        console.error('Error deleting record:', error);
    }
});

