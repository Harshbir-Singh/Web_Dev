var form = document.getElementById("form")
var display1 = 0;
var display2 = 0;
var display3 = 0;
var display4 = 0;



function ViewBook(){
    const deleteform = document.getElementById("delete-form")
    const updateform = document.getElementById("update-form")
    const addform = document.getElementById("add-form")
    const viewform = document.getElementById("view-form")
    if(display1 == 0){
        viewform.style.display = "flex"
        viewform.style.justifyContent = "center"
        addform.style.display = "none"
        updateform.style.display = "none"
        deleteform.style.display = "none"
        display1 = 1;

    }
    else{
        viewform.style.display = "none"
        display1 = 0;

    }

    
}

function AddBook(){
    const deleteform = document.getElementById("delete-form")
    const updateform = document.getElementById("update-form")
    const addform = document.getElementById("add-form")
    const viewform = document.getElementById("view-form")
    if(display2 == 0){
        viewform.style.display = "none"
        addform.style.display = "block"
        updateform.style.display = "none"
        deleteform.style.display = "none"
        display2 = 1;

    }
    else{
        addform.style.display = "none"
        display2 = 0;

    }

}    

function UpdateBook(){
    const deleteform = document.getElementById("delete-form")
    const updateform = document.getElementById("update-form")
    const addform = document.getElementById("add-form")
    const viewform = document.getElementById("view-form")
    if(display3 == 0){
        viewform.style.display = "none"
        addform.style.display = "none"
        updateform.style.display = "block"
        deleteform.style.display = "none"
        display3 = 1;

    }
    else{
        updateform.style.display = "none"
        display3 = 0;

    }

}


function DeleteBook(){
    const deleteform = document.getElementById("delete-form")
    const updateform = document.getElementById("update-form")
    const addform = document.getElementById("add-form")
    const viewform = document.getElementById("view-form")
    if(display4 == 0){
        viewform.style.display = "none"
        addform.style.display = "none"
        updateform.style.display = "none"
        deleteform.style.display = "block"
        display4 = 1;

    }
    else{
        deleteform.style.display = "none"
        display4 = 0;

    

    }
}


//Issuing book
document.addEventListener('DOMContentLoaded', function() {
    const issueBookForm = document.getElementById('add-form');

    issueBookForm.addEventListener('submit', async function(event) {
        event.preventDefault();

        const formData = new FormData(issueBookForm);
        const data = {
            BookID: formData.get('BookID'),
            StudentID: formData.get('StudentID'),
            StudentName: formData.get('StudentName'),
            Course: formData.get('Course'),
            Branch: formData.get('Branch')
        };

        try {
            const response = await fetch('/submit', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            if (response.ok) {
                window.location.href = 'Students.html';
            } else {
                const errorText = await response.text();
                alert(`Failed to issue book: ${errorText}`);
            }
        } catch (error) {
            alert('An error occurred while issuing the book');
            console.error('Error:', error);
        }
    });
});


//updating Student records    
document.addEventListener('DOMContentLoaded', function() {
    const updateStudentForm = document.getElementById('updateBookForm');

    updateStudentForm.addEventListener('submit', async function(event) {
        event.preventDefault();

        const formData = new FormData(updateStudentForm);
        const data = {
            bookID: formData.get('bookID'),
            studentID: formData.get('studentID'),
            branch: formData.get('branch')
        };

        try {
            const response = await fetch('/updateStudent', {
                method: 'POST', // Assuming you want to use POST for updates
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            if (response.ok) {
                alert('Student record updated successfully');
                window.location.href = 'Students.html'; 
            } else {
                const errorText = await response.text();
                if (response.status === 400 && errorText.includes('Duplicate Student ID')) {
                    alert('Error: Duplicate Student ID');
                } else {
                    alert(`Failed to update student record: ${errorText}`);
                }
            }
        } catch (error) {
            alert('An error occurred while updating the student record');
            console.error('Error:', error);
        }
    });
});



//deleting student records
async function deleteRecord() {
    const bookId = document.getElementById('bookId').value;
    const studentId = document.getElementById('studentId').value;

    try {
        const response = await fetch('/deleteRecord', {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ BookID: bookId, StudentID: studentId }),
        });

        if (response.ok) {
            alert('Record deleted successfully');
            window.location.href = 'Students.html'; 
        } else {
            alert('Record not found');
        }
    } catch (error) {
        console.error('Error deleting record:', error);
    }
}
