var form = document.getElementById("form")
var display1 = 0;
var display2 = 0;
var display3 = 0;
var display4 = 0;



function ViewBook(){
    const deleteform = document.getElementById("delete-form")
    const updateform = document.getElementById("update-form")
    const addform = document.getElementById("add-form")
    const viewform = document.getElementById("view-form")
    if(display1 == 0){
        viewform.style.display = "flex"
        viewform.style.justifyContent = "center"
        addform.style.display = "none"
        updateform.style.display = "none"
        deleteform.style.display = "none"
        display1 = 1;

    }
    else{
        viewform.style.display = "none"
        display1 = 0;

    }

    
}

function AddBook(){
    const deleteform = document.getElementById("delete-form")
    const updateform = document.getElementById("update-form")
    const addform = document.getElementById("add-form")
    const viewform = document.getElementById("view-form")
    if(display2 == 0){
        viewform.style.display = "none"
        addform.style.display = "block"
        updateform.style.display = "none"
        deleteform.style.display = "none"
        display2 = 1;

    }
    else{
        addform.style.display = "none"
        display2 = 0;

    }

}    

function UpdateBook(){
    const deleteform = document.getElementById("delete-form")
    const updateform = document.getElementById("update-form")
    const addform = document.getElementById("add-form")
    const viewform = document.getElementById("view-form")
    if(display3 == 0){
        viewform.style.display = "none"
        addform.style.display = "none"
        updateform.style.display = "block"
        deleteform.style.display = "none"
        display3 = 1;

    }
    else{
        updateform.style.display = "none"
        display3 = 0;

    }

}


function DeleteBook(){
    const deleteform = document.getElementById("delete-form")
    const updateform = document.getElementById("update-form")
    const addform = document.getElementById("add-form")
    const viewform = document.getElementById("view-form")
    if(display4 == 0){
        viewform.style.display = "none"
        addform.style.display = "none"
        updateform.style.display = "none"
        deleteform.style.display = "block"
        display4 = 1;

    }
    else{
        deleteform.style.display = "none"
        display4 = 0;

    

    }
}

//adding book
document.getElementById('add-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const bookID = document.getElementById('BookID').value;
    const bookName = document.getElementById('Name').value;
    const author = document.getElementById('Author').value;
    const price = document.getElementById('Price').value;
    const quantity = document.getElementById('Quantity').value;

    axios.post('/save', {
        BookID: bookID,
        Name: bookName,
        Author: author,
        Price: price,
        Quantity: quantity
    })
    .then(response => {
        alert('Book added successfully!');
        window.location.reload();
    })
    .catch(error => {
        const errorMessage = document.getElementById('error-message');
        if (error.response && error.response.status === 400) {
            errorMessage.textContent = 'Duplicate BookID. Please use a unique BookID.';
        } else {
            errorMessage.textContent = 'Failed to add book.';
        }
        errorMessage.style.display = 'block';
    });
});

//updating book
document.getElementById('updateBookForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const bookID = document.getElementById('updateBookID').value;
    const bookName = document.getElementById('updateBookName').value;
    const author = document.getElementById('updateAuthor').value;
    const price = document.getElementById('updatePrice').value;
    const quantity = document.getElementById('updateQuantity').value;

    axios.put('/updateBook', {
        bookID: bookID,
        bookName: bookName,
        author:author,
        price: price,
        quantity: quantity
    })
    .then(response => {
        alert('Book updated successfully!');
        window.location.reload();
    })
    .catch(error => {
        if (error.response && error.response.status === 404) {
            alert('Book not found. Please check the BookID.');
        } else {
            console.error('Failed to update book:', error);
            alert('Failed to update book. Please try again.');
        }
    });
});

// deleting book

function deleteBooks() {
    const bookID = document.getElementById('deleteBookID').value;
    const quantity = document.getElementById('deleteQuantity').value;

    axios.put(`/deleteBooks/${bookID}/${quantity}`)
    .then(response => {
        console.log(response.data);
        alert('Books deleted successfully!');
        window.location.reload();
    })
    .catch(error => {
        console.error(error);
        alert('Book Not Found');
    });
}




