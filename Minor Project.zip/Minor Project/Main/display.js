
async function fetchCounts() {

    try {
        const [bookResponse, studentResponse, issuedResponse] = await Promise.all([
            fetch('/countBooks'),
            fetch('/countStudents'),
            fetch('/countIssuedBooks')
        ]);

        if (!bookResponse.ok || !studentResponse.ok || !issuedResponse.ok) {
            throw new Error('Failed to fetch counts');
        }

        const bookData = await bookResponse.json();
        const studentData = await studentResponse.json();
        const issuedData = await issuedResponse.json();

        document.getElementById('BookNo').innerHTML = `<i class="material-icons">book</i> ${bookData.count}`;
        document.getElementById('StudentNo').innerHTML = `<i class="material-icons">face</i> ${studentData.count}`;
        document.getElementById('IssuedNo').innerHTML = `<i class="material-icons">book</i> ${issuedData.count}`;
    } catch (error) {
        console.error('Error fetching counts:', error);
    }
}

fetchCounts();

document.addEventListener('DOMContentLoaded', async function() {
    try {

        const booksResponse = await fetch('/book');
        const booksData = await booksResponse.json();
        
 
        const booksTable = document.getElementById('booksTable');
        booksData.slice(0, 4).forEach(book => {
            const row = booksTable.insertRow();
            row.innerHTML = `<td>${book.BookID}</td><td>${book.Name}</td><td>${book.Author}</td><td>${book.Quantity}</td>`;
        });

  
        for (let i = booksData.length; i < 4; i++) {
            const row = booksTable.insertRow();
            row.innerHTML = `<td>None</td><td>None</td><td>None</td><td>None</td>`;
        }


        const studentsResponse = await fetch('/student');
        const studentsData = await studentsResponse.json();
        

        const studentsTable = document.getElementById('studentsTable');
        studentsData.slice(0, 4).forEach(student => {
            const row = studentsTable.insertRow();
            row.innerHTML = `<td>${student.StudentID}</td><td>${student.StudentName}</td><td>${student.Course}</td><td>${student.Branch}</td>`;
        });

        // Fill empty rows if less than 4 records
        for (let i = studentsData.length; i < 4; i++) {
            const row = studentsTable.insertRow();
            row.innerHTML = `<td>None</td><td>None</td><td>None</td><td>None</td>`;
        }

    } catch (error) {
        console.error('Error fetching and displaying data:', error);
    }
});


document.addEventListener('DOMContentLoaded', () => {
    fetch('/book')
        .then(response => response.json())
        .then(data => {
            const tableBody = document.getElementById('data-body');
            data.forEach(item => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${item.BookID}</td>
                    <td>${item.Name}</td>
                    <td>${item.Author}</td>
                    <td>${item.Price}</td>
                    <td>${item.Quantity}</td>
                `;
                tableBody.appendChild(row);
            });
        })
        .catch(error => console.error('Error fetching data:', error));
});



document.addEventListener('DOMContentLoaded', () => {
    fetch('/student')
        .then(response => response.json())
        .then(data => {
            const tableBody = document.getElementById('databody');
            data.forEach(item => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${item.BookID}</td>
                    <td>${item.StudentID}</td>
                    <td>${item.StudentName}</td>
                    <td>${item.Course}</td>
                    <td>${item.Branch}</td>
                `;
                tableBody.appendChild(row);
            });
        })
        .catch(error => console.error('Error fetching data:', error));
});